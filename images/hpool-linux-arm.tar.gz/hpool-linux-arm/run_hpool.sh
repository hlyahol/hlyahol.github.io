while :
do
  count=`ps -ef |grep hpool |grep -v "grep" |wc -l` ; echo $count
  if [ 2 == $count ];then
    #open -n hpool-miner-chia.app
    ./hpool-chia-miner-linux-arm
  fi
  sleep 30
done
